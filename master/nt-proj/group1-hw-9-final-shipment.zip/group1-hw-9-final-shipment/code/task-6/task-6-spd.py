import scipy.io as spio
import matplotlib.pyplot as plt
import numpy as np


def load_data(file):
    mat = spio.loadmat(file, squeeze_me=True)
    datenums = mat["datenums"]
    ranges = mat["ranges"]
    data = mat["data"]
    t = (datenums - np.floor(np.min(datenums))) * 24
    return (t, ranges, data, mat)


def get_spectra(data, ts):
    """
    assumes time series data is distributed along axis=1
    """
    N = data.shape[1]
    spectra = np.fft.fft(data, axis=1) / N
    freq = np.fft.fftfreq(N, ts)
    freq = np.fft.fftshift(freq)
    spectra = np.fft.fftshift(spectra, axes=1)
    return (freq, spectra)


def remove_dc(data):
    noDP = np.size(data, 1)
    dc = np.repeat(np.mean(data, axis=1)[:, :, np.newaxis], noDP, axis=2)
    dc = np.swapaxes(dc, 1, 2)
    return data - dc


def apply_phase_correction(data, correction_list):
    """
    assumes correction_list values in degrees
    """
    rxs = np.size(data, 2)
    data_corrected = data
    for rx in range(0, rxs):
        data_corrected[:, :, rx] = \
                data[:, :, rx] * np.exp(1j * np.deg2rad(correction_list[rx]))
    return data_corrected


file = "../data/20230620_MAARSY_2_Gr1_5_RAW"

phase_corrections = [0.0, -5.1, 0.0, -7.75]

t, ranges, data, mat = load_data(file)
print("data duration hours:")
print(np.max(t) - np.min(t))

tsec = t * 60 * 60

data_corrected = apply_phase_correction(data, phase_corrections)
data = remove_dc(data_corrected)

# 6a) superposition of channels 2-4
rx_1 = data[..., 0]
# rx_sup = np.mean(data[..., 2:], axis=2)
rx_sup = np.sum(data[..., 2:], axis=2)
pow_rx_1 = 20*np.log10(np.mean(np.abs(rx_1), 1))
pow_rx_sup = 20*np.log10(np.mean(np.abs(rx_sup), 1))

# echo power plot
plt.figure()
plt.plot(pow_rx_1, ranges, label="Receiver 1")
plt.plot(pow_rx_sup, ranges, label="Superpos. Receivers 2-5")
plt.xlabel("power / dB$V^2$")
plt.ylabel("range / km")
plt.title("Received Power")
plt.legend()

plt.show()
