import scipy.io as spio
import matplotlib.pyplot as plt
import numpy as np
import itertools


def load_data(file):
    mat = spio.loadmat(file, squeeze_me=True)
    datenums = mat["datenums"]
    ranges = mat["ranges"]
    data = mat["data"]
    antpos = mat["antpos"]
    wl = mat["wl"]
    t = (datenums - np.floor(np.min(datenums))) * 24
    return (t, ranges, data, antpos, wl)


def get_spectra(data, ts):
    """
    assumes time series data is distributed along axis=1
    """
    N = data.shape[1]
    spectra = np.fft.fft(data, axis=1) / N
    freq = np.fft.fftfreq(N, ts)
    freq = np.fft.fftshift(freq)
    spectra = np.fft.fftshift(spectra, axes=1)
    return (freq, spectra)


def get_pairs(antpos):
    """
    Returns list of pairs of antennas
    """
    num_ant = len(antpos)
    pairs = itertools.combinations(range(0, num_ant), 2)
    return list(pairs)


def calc_aoa_t(antpos, data, wl):
    """
    Calculates the angles of arrival (dcosx / dcosy)
    for this array for the given input data
    for every time sample point
    """

    noRG = np.size(data, 0)
    noDP = np.size(data, 1)

    pairs = get_pairs(antpos)

    nopairs = np.size(pairs, 0)

    dx = np.zeros([nopairs])
    dy = np.zeros([nopairs])
    phases = np.zeros([noRG, noDP, nopairs])

    for pp in range(nopairs):
        # calculate position differences between
        # first and second antenna in pair
        dx[pp] = (antpos[pairs[pp][0]] - antpos[pairs[pp][1]]).real
        dy[pp] = (antpos[pairs[pp][0]] - antpos[pairs[pp][1]]).imag

        # calculate the phases for each range gate and time sample
        # by taking the data of the first antenna of the pair
        # multiplied with the complex conjugate of the second
        # --> this gives the difference angle in the complex number
        phases[:, :, pp] = np.angle(
                    data[:, :, pairs[pp][0]] *
                    np.conjugate(data[:, :, pairs[pp][1]]),
                )

    R = 2*np.pi / wl * np.array([dx, dy])
    R = R.transpose()

    # least squares matrix solving
    # numpy linalg
    # https://numpy.org/doc/stable/reference/generated/numpy.linalg.solve.html
    B = np.matmul(np.mat(R).T, np.mat(R))
    pos_data = np.zeros([noRG, noDP, 2])
    phi = np.zeros([noRG, noDP, 1])
    theta = np.zeros([noRG, noDP, 1])

    for rg in range(noRG):
        for dp in range(noDP):
            b = np.matmul(np.mat(R).T, np.mat(phases[rg, dp, :]).T)
            r = np.linalg.solve(B.T.dot(B), B.T.dot(b))
            pos_data[rg, dp, :] = r.T
            phi[rg, dp] = np.arctan2(r[1], r[0])
            theta[rg, dp] = np.arcsin(np.sqrt(r[0]**2+r[1]**2))

    return (pos_data, phi, theta)


def calc_aoa(antpos, data, wl):
    """
    Calculates the angles of arrival (dcosx / dcosy)
    for this array for the given input data
    taking an average phase approach
    """

    noRG = np.size(data, 0)

    pairs = get_pairs(antpos)

    nopairs = np.size(pairs, 0)

    dx = np.zeros([nopairs])
    dy = np.zeros([nopairs])
    phases = np.zeros([noRG, nopairs])

    for pp in range(nopairs):
        # calculate position differences between
        # first and second antenna in pair
        dx[pp] = (antpos[pairs[pp][0]] - antpos[pairs[pp][1]]).real
        dy[pp] = (antpos[pairs[pp][0]] - antpos[pairs[pp][1]]).imag

        phases[:, pp] = np.angle(
                np.mean(
                    data[:, :, pairs[pp][0]] *
                    np.conjugate(data[:, :, pairs[pp][1]]),
                    axis=1
                    )
                )

    R = 2*np.pi / wl * np.array([dx, dy])
    R = R.transpose()

    # least squares matrix solving
    # numpy linalg
    # https://numpy.org/doc/stable/reference/generated/numpy.linalg.solve.html

    B = np.matmul(np.mat(R).T, np.mat(R))
    pos_data = np.zeros([noRG, 2])
    phi = np.zeros([noRG, 1])
    theta = np.zeros([noRG, 1])

    for rg in range(noRG):
        b = np.matmul(np.mat(R).T, np.mat(phases[rg, :]).T)
        r = np.linalg.solve(B.T.dot(B), B.T.dot(b))
        pos_data[rg, :] = r.T
        phi[rg] = np.arctan2(r[1], r[0])
        theta[rg] = np.arcsin(np.sqrt(r[0]**2+r[1]**2))

    return (pos_data, phi, theta)


def remove_dc(data):
    noDP = np.size(data, 1)
    dc = np.repeat(np.mean(data, axis=1)[:, :, np.newaxis], noDP, axis=2)
    dc = np.swapaxes(dc, 1, 2)
    return data - dc


def apply_phase_correction(data, correction_list):
    """
    assumes correction_list values in degrees
    """
    rxs = np.size(data, 2)
    data_corrected = data
    for rx in range(0, rxs):
        data_corrected[:, :, rx] = \
                data[:, :, rx] * np.exp(1j * np.deg2rad(correction_list[rx]))
    return data_corrected


def my_savefig(name):
    plt.savefig("output/" + name)


# -------------------------------------------------------------------------
# Calculations
# -------------------------------------------------------------------------

file = "../data/20230620_MAARSY_2_Gr1_5_RAW.mat"

phase_corrections = [0.0, -5.1, 0.0, -7.75]

t, ranges, data, antpos, wl = load_data(file)
antpos = antpos[1:]  # ignore first combined antenna
print("data duration hours:")
print(np.max(t) - np.min(t))

tsec = t * 60 * 60

data_corrected = apply_phase_correction(data, phase_corrections)
data = remove_dc(data_corrected)

# 6a) superposition of channels 2-4
rx_1 = data[..., 0]
# rx_sup = np.mean(data[..., 2:], axis=2)
rx_sup = np.sum(data[..., 1:], axis=2)
pow_rx_1 = 20*np.log10(np.mean(np.abs(rx_1), 1))
pow_rx_sup = 20*np.log10(np.mean(np.abs(rx_sup), 1))

print(np.shape(data[..., 1:]))

# 6b) calculation of aoa for every time sample
print(antpos)
print(get_pairs(antpos))

pos_data, phi, theta = calc_aoa(antpos, data[..., 1:], wl)

# -------------------------------------------------------------------------
# Plotting
# -------------------------------------------------------------------------

# echo power plot
plt.figure()
plt.plot(pow_rx_1, ranges, label="Receiver 1")
plt.plot(pow_rx_sup, ranges, label="Superpos. Receivers 2-4")
plt.xlabel("power / dB$V^2$")
plt.ylabel("range / km")
plt.title("Received Power")
plt.legend()
plt.grid()

my_savefig("t6_power.pdf")

# plot antenna positions
plt.figure()
plt.scatter(antpos.real / wl, antpos.imag / wl)
plt.title("Antenna Positions")
plt.xlabel("x / $\\lambda$")
plt.ylabel("y / $\\lambda$")
plt.grid()

my_savefig("t6_antpos.pdf")

# aoa vs range
plt.figure()
plt.plot(np.rad2deg(phi[..., 0]), ranges, label="$\\phi$")
plt.plot(np.rad2deg(theta[..., 0]), ranges, label="$\\theta$")
plt.xlim(-180, 180)
plt.title("$\\phi$ and $\\theta$ vs Range")
plt.xlabel("angle / °")
plt.ylabel("range / km")
plt.legend()
plt.grid()

my_savefig("t6_aoa_range.pdf")

# plt.figure()
# plt.scatter(pos_data[:, 0], pos_data[:, 1])
# plt.xlim([-1, 1])
# plt.ylim([-1, 1])
# plt.grid(1)
# plt.xlabel("$dcosx=\\sin(\\theta)\\cos(\\phi)$")
# plt.ylabel("$dcosy=\\sin(\\theta)\\sin(\\phi)$")

# see
# https://stackoverflow.com/questions/31768031/plotting-points-on-the-surface-of-a-sphere
# Create a sphere
r = 1
phi1, theta1 = np.mgrid[0.0:np.pi/2:50j, 0.0:2.0*np.pi:50j]
x = r*np.sin(phi1)*np.cos(theta1)
y = r*np.sin(phi1)*np.sin(theta1)
z = r*np.cos(phi1)

# dcx = pos_data[:, 0]
# dcy = pos_data[:, 1]
# phi = np.arctan2(dcx/dcy)
# theta = np.arcsin(dcy * np.sqrt((dcx**2 + dcy**2)/(dcy**2)))

r = 1.0
xx = r * np.sin(theta) * np.sin(phi)
yy = r * np.sin(theta) * np.cos(phi)
zz = r * np.cos(theta)

# sphere surface scatter plot for phase average
fig = plt.figure(constrained_layout=True, figsize=(13, 6))
ax = fig.add_subplot(122, projection='3d')

ax.plot_surface(
    x, y, z,  rstride=1, cstride=1, color='c', alpha=0.3, linewidth=0)

ax.scatter(xx, yy, zz, c=zz, cmap="viridis", s=20)
ax.set_aspect("equal")

plt.suptitle("Angle of Arrival Positions on the Sphere")
plt.title("Averaged Phase Method")
plt.xlabel("x")
plt.ylabel("y")
ax.set_zlabel("z")

# version 2: aoa for each time sample
pos_data, phi, theta = calc_aoa_t(antpos, data[..., 1:], wl)
phi_c = phi.copy()
theta_c = theta.copy()

r = 1
phi1, theta1 = np.mgrid[0.0:np.pi/2:50j, 0.0:2.0*np.pi:50j]
x = r*np.sin(phi1)*np.cos(theta1)
y = r*np.sin(phi1)*np.sin(theta1)
z = r*np.cos(phi1)

dcx = pos_data[:, 0]
dcy = pos_data[:, 1]
phi = np.arctan(dcx/dcy)
theta = np.arcsin(dcy * np.sqrt((dcx**2 + dcy**2)/(dcy**2)))

r = 1.0
xx = r * dcx
yy = r * dcy
zz = r * np.cos(theta)

# sphere surface scatter plot for full time series aoa
# fig = plt.figure()
ax = fig.add_subplot(121, projection='3d')

ax.plot_surface(
    x, y, z,  rstride=1, cstride=1, color='c', alpha=0.3, linewidth=0)

ax.scatter(xx, yy, zz, c=zz, cmap="viridis", s=20)
ax.set_aspect("equal")

print(phi_c.shape)
print(theta_c.shape)
# plt.suptitle("Angle of Arrival Positions on the Sphere")
plt.title("Non-Averaged Phase Method")
plt.xlabel("x")
plt.ylabel("y")
ax.set_zlabel("z")

my_savefig("t6_sphere_scatter.pdf")

# pcolor plots for phi and theta angles of arrival
plt.figure()
plt.pcolor(t, ranges, np.rad2deg(phi_c[..., 0]), cmap="jet", rasterized=True)
cbar = plt.colorbar()
plt.clim(-180, 180)
plt.xlabel("t / h")
plt.ylabel("range / km")
cbar.ax.set_ylabel("$\\phi$ / °")
plt.title("$\\phi$ vs Range and Time")
plt.tight_layout()

my_savefig("t6_aoa_time_phi.pdf")

plt.figure()
plt.pcolor(t, ranges, np.rad2deg(theta_c[..., 0]), cmap="jet", rasterized=True)
cbar = plt.colorbar()
plt.clim(-20, 20)
plt.xlabel("t / h")
plt.ylabel("range / km")
cbar.ax.set_ylabel("$\\theta$ / °")
plt.title("$\\theta$ vs Range and Time")
plt.tight_layout()


my_savefig("t6_aoa_time_theta.pdf")

plt.show()
