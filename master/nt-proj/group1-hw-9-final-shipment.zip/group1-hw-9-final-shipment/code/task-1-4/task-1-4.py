import scipy.io as spio
import os
import matplotlib.pyplot as plt
import numpy as np

currentfile = '../data/2023061005_Saura_Gr1_RAW.mat'

print('reading file:')
print(currentfile)

# importing MATLAB mat file   (containing radar raw data)
mat = spio.loadmat(currentfile, squeeze_me=True)

datenums = mat['datenums']
ranges   = mat['ranges']
data     = np.complex64(mat['data'])
antpos   = np.complex64(mat['antpos'])
wl       = mat['wl']

# datenums ~ days since year 0
# here only the time is important for us -> hours, minutes, seconds
# => fraction / remainder of the integer

t=(datenums-np.floor(np.min(datenums)))*24

# number of range gates , data points, receivers
noRG=np.size(data,0)
noDP=np.size(data,1)
noRx=np.size(data,2)

# perform coherent integrations
def make_ci(t, y, ci):
    nptsn=int(np.floor(len(y)/ci))
    yn=np.empty(nptsn)+1j*np.empty(nptsn)
    tn=np.empty(nptsn)
    for i in range(0,nptsn):
        yn[i]=np.mean(y[i*ci:i*ci+ci-1])
        tn[i]=np.mean(t[i*ci:(i+1)*ci])
    return tn,yn

# perform incoherent integrations
def make_nci(t, y, ci):
    nptsn=int(np.floor(len(y)/ci))
    yn=np.empty(nptsn)+1j*np.empty(nptsn)
    tn=np.empty(nptsn)
    for i in range(0,nptsn):
        yn[i]=np.mean(np.abs(y[i*ci:i*ci+ci-1]))
        tn[i]=np.mean(t[i*ci:(i+1)*ci])
    return tn,yn

def coherent_integration(time, data, ci):
    # how many splits
    n_data_split = int(np.floor(data.shape[1] / ci))

    split_data = np.array_split(data, n_data_split, axis=1)
    split_time = np.array_split(time, n_data_split)

    newlist = []
    timelist = []
    for i, m in enumerate(split_data):
        dat_mean = np.mean(m, axis=1)
        newlist.append(dat_mean)
        timelist.append(np.mean(split_time[i]))

    new_data = np.stack(newlist, axis=1)
    new_time = np.stack(timelist)

    return (new_time, new_data)

def get_spectra(data, ts):
    """
    assumes time series data is distributed along axis=1
    """
    N = data.shape[1]
    spectra = np.fft.fft(data, axis=1) / N
    freq = np.fft.fftfreq(N, ts)
    freq = np.fft.fftshift(freq)
    spectra = np.fft.fftshift(spectra, axes=1)
    return (freq, spectra)

def rx_cross_spectra2(spectra, rx1_idx, rx2_idx):
    spec_rx1 = spectra[:, :, rx1_idx]
    spec_rx2 = spectra[:, :, rx2_idx]
    xspec = np.multiply(spec_rx1, np.conj(spec_rx2))
    return xspec

def my_savefig(name):
    plt.savefig("output/" + name)

# Phase-correction - Receiver / antenna phases

# calibration phases:
RXPhases=[0, 0, -4.4, -6.5, -5.95, -7.85]
RXPhases=np.mat(RXPhases)*-1/180*np.pi

# receiver phase adjustment 
for rx in range (noRx):
    data[rx,:,:]=data[rx,:,:]*np.exp(1j*RXPhases[0,rx])   # used receiver are 7,8,9


## Question 1 ###
# Spectrum freq axis calculation, due small difference in time stamp spacing, sampling frequency is calculated form using full data
Ts      = (np.max(t)-np.min(t))/(len(t)-1)
# Fs      = 1/deltaT                                # average sampling frequency over the time stamps
# freq    = np.linspace(-Fs/2, Fs/2, len(t))
freq    = np.fft.fftshift( np.fft.fftfreq( len(t), Ts ) )  

Rgrid, Fgrid = np.meshgrid(ranges, freq, indexing='ij')   ## creating a mesh to plot in pcolor

# Spectrum calculation for all receivers
Spectrum = data*0.0
for rx in range (noRx):
    for rg in range(noRG):
        Spectrum[rg, :, rx] = np.fft.fftshift( np.fft.fft( data[rg,:,rx] ) )/ len(freq) # spectrum for each range gate and receiver

# plots for receiver 1, array beam
plt.figure('11m')
plt.pcolor(Fgrid/1000, Rgrid, 20*np.log10( np.abs(Spectrum[:,:,0]) ), cmap='jet', shading='auto', rasterized=True,)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Magnitude Rx1 / dB')
plt.clim(20,np.max( 20*np.log10( np.abs(Spectrum[:,:,0]) )) )
plt.colorbar()

# my_savefig("t1-mag-rx1.pdf")

plt.figure('11p')
plt.pcolor(Fgrid/1000, Rgrid, np.angle(Spectrum[:,:,0]), cmap='jet', shading='auto', rasterized=True)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Phase Rx1 / rad')
# plt.clim(10,50)
plt.colorbar()

# my_savefig("t1-phase-rx1.pdf")

# plots for receiver 2, individual antenna
plt.figure('12m')
plt.pcolor(Fgrid/1000, Rgrid, 20*np.log10( np.abs( Spectrum[:,:,1] ) ), cmap='jet', shading='auto', rasterized=True)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Magnitude Rx2 / dB')
plt.clim(20,np.max( 20*np.log10( np.abs(Spectrum[:,:,1]) )) )
plt.colorbar()

# my_savefig("t1-mag-rx2.pdf")

plt.figure('12p')
plt.pcolor(Fgrid/1000, Rgrid, np.angle(Spectrum[:,:,1]), cmap='jet', shading='auto', rasterized=True)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Phase Rx2 / rad')
# plt.clim(10,50)
plt.colorbar()

# my_savefig("t1-phase-rx2.pdf")

# plots for receivers 2-5 combined
# plt.figure('13m')
# plt.pcolor(Rgrid, Fgrid/1000, 20*np.log10( np.abs( np.sum( Spectrum[:,:,1:], axis=-1) ) ), cmap='jet', shading='auto', rasterized=True)
# plt.ylabel('Range')
# plt.ylabel('Frequency /kHz')
# plt.title('Magnitude /dB')
# plt.clim(20,np.max( 20*np.log10( np.abs( np.sum( Spectrum[:,:,1:], axis=-1)  ) )) )
# plt.colorbar()

# plt.figure('13p')
# plt.pcolor(Rgrid, Fgrid/1000, np.angle(np.sum( Spectrum[:,:,1:], axis=-1)), cmap='jet', shading='auto', rasterized=True)
# plt.ylabel('Range')
# plt.ylabel('Frequency /kHz')
# plt.title('Phase /rad')
# # plt.clim(10,50)
# plt.colorbar()

### Question 2 ###
data_superposition = np.sum( data[:,:,1:], axis=-1)  # sum of data from all receivers 2-5, sum is happening over -1 or last axis, i.e. sum over all given receivers

Spectrum_superposition = data_superposition*0.0

for rg in range(noRG):
    Spectrum_superposition[rg, :] = np.fft.fftshift( np.fft.fft( data_superposition[rg,:] ) )/ len(freq) 
#

Spectrum_combination   = np.sum( Spectrum[:,:,1:], axis=-1) # sum of spectrum of all receivers 2-5

plt.figure('21m')
plt.pcolor(Fgrid/1000, Rgrid, 20*np.log10( np.abs(Spectrum_superposition[:,:]) ), cmap='jet', shading='auto', rasterized=True)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Receiver Data Superposition Spectrum Magnitude / dB')
plt.clim(20,np.max( 20*np.log10( np.abs(Spectrum_superposition[:,:]) )) )
plt.colorbar()
# my_savefig("t2-sup-mag.pdf")

plt.figure('21p')
plt.pcolor(Fgrid/1000, Rgrid, np.angle(Spectrum_superposition[:,:]), cmap='jet', shading='auto', rasterized=True)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Receiver Data Superposition Spectrum Phase / rad')
# plt.clim(10,50)
plt.colorbar()
# my_savefig("t2-sup-phase.pdf")

plt.figure('22m')
plt.pcolor(Fgrid/1000, Rgrid, 20*np.log10( np.abs( Spectrum_combination[:,:] ) ), cmap='jet', shading='auto', rasterized=True)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Receiver Spectrum Combination Magnitude / dB')
plt.clim(20,np.max( 20*np.log10( np.abs(Spectrum_combination[:,:]) )) )
plt.colorbar()
# my_savefig("t2-comb-mag.pdf")

plt.figure('22p')
plt.pcolor(Fgrid/1000, Rgrid, np.angle(Spectrum_combination[:,:]), cmap='jet', shading='auto', rasterized=True)
plt.ylabel('Range')
plt.xlabel('Frequency / kHz')
plt.title('Receiver Spectrum Combination Phase / rad')
# plt.clim(10,50)
plt.colorbar()
# my_savefig("t2-comb-phase.pdf")

### Question 3 ###
# Plots from question 1 for reference
# plots for receiver 1, array beam
# plt.figure('31m_ref')
# plt.pcolor(Fgrid/1000, Rgrid, 20*np.log10( np.abs(Spectrum[:,:,0]) ), cmap='jet', shading='auto', rasterized=True)
# plt.ylabel('Range')
# plt.xlabel('Frequency / kHz')
# plt.title('Magnitude / dB')
# plt.clim(10,np.max( 20*np.log10( np.abs(Spectrum[:,:,0]) )) )
# plt.colorbar()

t_ci, data_ci = coherent_integration(t, data, 8)
tsec = t_ci * 60 * 60
ts = tsec[42] - tsec[41]
f, specs = get_spectra(data_ci, ts)

# rx1 plot ci data

plt.figure()
plt.pcolor(f, ranges, 20*np.log10(np.abs(specs[..., 0])), cmap="jet", rasterized=True)
plt.colorbar()
plt.xlabel('Frequency / kHz')
plt.ylabel('Range')
plt.clim(10, 62)
plt.title("Rx1 magnitude after CI / dB")
my_savefig("t3-mag-rx1.pdf")

plt.figure()
plt.pcolor(f, ranges, np.angle(specs[..., 0]), cmap="jet", rasterized=True)
plt.colorbar()
plt.xlabel('Frequency / kHz')
plt.ylabel('Range')
plt.clim(-np.pi, np.pi)
plt.title("Rx1 phase after CI / rad")
my_savefig("t3-phase-rx1.pdf")

# same for rx2

plt.figure()
plt.pcolor(f, ranges, 20*np.log10(np.abs(specs[..., 1])), cmap="jet", rasterized=True)
plt.colorbar()
plt.xlabel('Frequency / kHz')
plt.ylabel('Range')
plt.clim(10, 62)
plt.title("Rx2 magnitude after CI / dB")
my_savefig("t3-mag-rx2.pdf")

plt.figure()
plt.pcolor(f, ranges, np.angle(specs[..., 1]), cmap="jet", rasterized=True)
plt.colorbar()
plt.xlabel('Frequency / kHz')
plt.ylabel('Range')
plt.clim(-np.pi, np.pi)
plt.title("Rx2 phase after CI / rad")
my_savefig("t3-phase-rx2.pdf")

## Question 4 --> Cross spectra

def plot_xspec(xspec, l1, l2):
    # mag plot
    plt.figure()
    plt.pcolor(f, ranges, 20*np.log10(np.abs(xspec)), cmap="jet", rasterized=True)
    plt.colorbar()
    plt.xlabel('Frequency / kHz')
    plt.ylabel('Range')
    plt.clim(-10, 70)
    plt.title("Cross spectrum magnitude of Rx" + l1 + "-Rx" + l2 + " / dB")
    my_savefig("t4-mag-" + l1 + "-" + l2 + ".pdf")
    
    # phase plot
    plt.figure()
    plt.pcolor(f, ranges, np.angle(xspec), cmap="jet", rasterized=True)
    plt.colorbar()
    plt.xlabel('f / kHz')
    plt.ylabel('Range')
    plt.clim(-np.pi, np.pi)
    plt.title("Cross spectrum phase of Rx" + l1 + "-Rx" + l2 +" / rad")
    my_savefig("t4-phase-" + l1 + "-" + l2 + ".pdf")

x_spec_2_3 = rx_cross_spectra2(specs, 1, 2)
x_spec_2_4 = rx_cross_spectra2(specs, 1, 3)
x_spec_2_5 = rx_cross_spectra2(specs, 1, 4)
x_spec_3_4 = rx_cross_spectra2(specs, 2, 3)
x_spec_3_5 = rx_cross_spectra2(specs, 2, 4)
x_spec_4_5 = rx_cross_spectra2(specs, 3, 4)

# plotting all the cross spectra
plot_xspec(x_spec_2_3, "2", "3")
plot_xspec(x_spec_2_4, "2", "4")
plot_xspec(x_spec_2_5, "2", "5")
plot_xspec(x_spec_3_4, "3", "4")
plot_xspec(x_spec_3_5, "3", "5")
plot_xspec(x_spec_4_5, "4", "5")