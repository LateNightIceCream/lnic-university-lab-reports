
import matplotlib.pyplot as plt
import numpy as np
import itertools

# plt.style.use('ggplot')
# plt.rcParams['text.usetex'] = True
# plt.rcParams['figure.figsize'] = 14, 14
# plt.rcParams['font.size'] = 30
# plt.rcParams['figure.titlesize'] = 46


class AntennaArray:
    def __init__(self, lam):
        self.pos = self.get_geometry()
        self.lam = lam

    def get_geometry(self):
        """
        should return the array of complex positions
        overridden by child classes
        """
        return np.zeros(1)

    def get_contour(self, npts):
        """
        Return xy values for the underlying shape of the array
        """
        return -1

    # ----------------------------------------------------------------------------
    # From HW6
    # ----------------------------------------------------------------------------

    def get_array_factor_dcos(self, dcosx, dcosy, target_theta, target_phi):
        """
        calculates the array factor for a specific positions
        (directional cosines)
        """
        steering_weights = self.get_steering_weights_for_target(target_theta,
                                                                target_phi)
        xn = self.pos.real
        yn = self.pos.imag

        AF = np.sum(steering_weights *
                    np.exp(-1j*2*np.pi/self.lam * (xn * dcosx + yn * dcosy)))

        return AF

    def get_steering_weights_for_target(self, target_theta, target_phi):
        """
        calculates weights (phases) based on target location
        (phased weights)
        """
        xn = self.pos.real
        yn = self.pos.imag

        angle = 2*np.pi / self.lam * np.sin(target_theta) *\
            (xn * np.cos(target_phi) +
                yn * np.sin(target_phi))

        return np.exp(1j*angle)

    # ----------------------------------------------------------------------------
    # /From HW6
    # ----------------------------------------------------------------------------

    def get_pairs(self):
        """
        Returns list of pairs of antennas
        """
        num_ant = len(self.get_geometry())
        pairs = itertools.combinations(range(0, num_ant), 2)
        return list(pairs)

    def calc_aoa(self, data):
        """
        Calculates the angles of arrival (dcosx / dcosy)
        for this array for the given input data
        """

        noRG = np.size(data, 0)

        pairs = self.get_pairs()
        wl = self.lam
        antpos = self.get_geometry()

        nopairs = np.size(pairs, 0)

        dx = np.zeros([nopairs])
        dy = np.zeros([nopairs])
        phases = np.zeros([noRG, nopairs])

        for pp in range(nopairs):
            # calculate position differences between
            # first and second antenna in pair
            dx[pp] = (antpos[pairs[pp][0]] - antpos[pairs[pp][1]]).real
            dy[pp] = (antpos[pairs[pp][0]] - antpos[pairs[pp][1]]).imag
            # calculate phases as phase (angle) of the mean of
            # the data (all ranges/time) of first receiver multiplied by
            # conjugate of second receiver
            # (yields complex number with phase difference)
            phases[:, pp] = np.angle(
                    np.nanmean(
                        data[:, :, pairs[pp][0]] * np.conjugate(data[:, :, pairs[pp][1]]),
                        axis=1
                        )
                    )

        R = 2*np.pi / wl * np.array([dx, dy])
        R = R.transpose()

        # least squares matrix solving
        # numpy linalg
        # https://numpy.org/doc/stable/reference/generated/numpy.linalg.solve.html

        B = np.matmul(np.mat(R).T, np.mat(R))
        pos_data = np.zeros([noRG, 2])
        phi = np.zeros([noRG, 1])
        theta = np.zeros([noRG, 1])

        for rg in range(noRG):
            b = np.matmul(np.mat(R).T, np.mat(phases[rg, :]).T)
            r = np.linalg.solve(B.T.dot(B), B.T.dot(b))
            pos_data[rg, :] = r.T
            phi[rg] = np.arctan2(r[1], r[0]) / np.pi*180
            theta[rg] = np.arcsin(np.sqrt(r[0]**2+r[1]**2))/np.pi*180

        return (pos_data, phi, theta)


class CircularArray(AntennaArray):
    def __init__(self, lam, num_ant, spacing):
        self.num_ant = num_ant
        self.spacing = spacing
        super().__init__(lam)

    def get_geometry(self):
        return self.geometry_variation_1()

    def geometry_variation_1(self):
        """
        Calculates the circle's radius such that the antennas
        have the same linear distance (self.spacing)
        towards their neighbors
        """
        angle_step = 2 * np.pi / self.num_ant
        radius = (self.spacing / 2) / (np.sin(angle_step / 2))
        pos_idx = np.arange(0, self.num_ant)
        pos = radius * np.exp(1j * angle_step * pos_idx)
        return pos

    def geometry_variation_2(self):
        """
        Sets the radius to self.spacing / 2 and calculates
        the positions accordingly
        (opposing antennas are self.spacing apart)
        """
        angle_step = 2 * np.pi / self.num_ant
        radius = self.spacing / 2
        pos_idx = np.arange(0, self.num_ant)
        pos = radius * np.exp(1j * angle_step * pos_idx)
        return pos

    def geometry_variation_3(self):
        """
        Same as self.geometry_variation_1 but takes
        arc length instead of direct length
        """
        angle_step = 2 * np.pi / self.num_ant
        radius = self.spacing / angle_step
        pos_idx = np.arange(0, self.num_ant)
        pos = radius * np.exp(1j * angle_step * pos_idx)
        return pos

    def get_contour(self, npts):
        angle_step = 2 * np.pi / self.num_ant
        radius = (self.spacing / 2) / (np.sin(angle_step / 2))
        angle = np.linspace(0, 2*np.pi, npts)
        return radius * np.exp(1j * angle)


class SpiralArray(AntennaArray):
    def __init__(self, lam, num_ant, spacing):
        self.num_ant = num_ant
        self.spacing = spacing
        super().__init__(lam)

    def get_geometry(self):
        a = 1
        b = 0.1
        turns = 2
        max_angle = 2 * np.pi * turns
        idx = np.arange(0, self.num_ant)
        angle_step = max_angle / self.num_ant
        return a * np.exp((b + 1j) * angle_step * idx)

    def get_contour(self, npts):
        a = 1
        b = 0.1
        turns = 2
        max_angle = 2 * np.pi * turns
        angle = np.linspace(0.0, max_angle * turns, npts)
        return a * np.exp((b + 1j) * angle)


def get_random_test_data(size):
    s = 1 / np.sqrt(2)
    data = np.random.normal(loc=0, scale=s, size=size) +\
        1j*np.random.normal(loc=0, scale=s, size=size)
    return data


def my_savefig(name):
    plt.savefig("output/" + name)


def main():

    f = 100e6
    c = 3e8
    lam = c / f

    spacing = 1.0 * lam

    num_ant = 6

    circle_array = CircularArray(lam, num_ant, spacing)
    spiral_array = SpiralArray(lam, num_ant, spacing)

    # ----------------------------------------------------------------------------
    # AOA
    # ----------------------------------------------------------------------------

    # 200 ranges, 2000 DP
    data = get_random_test_data((200, 2000, num_ant))

    pos_data_circle, phi_circ, theta_circ = circle_array.calc_aoa(data)
    pos_data_spiral, phi_spir, theta_spir = spiral_array.calc_aoa(data)

    # ----------------------------------------------------------------------------
    # Radiation Patterns
    # ----------------------------------------------------------------------------
    target_phi = 0
    target_theta = 0
    target_azm = np.mod(90 - target_phi, 360)

    dcx = np.linspace(-1, 1, 100)
    dcy = np.linspace(-1, 1, 100)

    afs_circle = np.zeros([100, 100])
    afs_spiral = np.zeros([100, 100])
    for i, dx in enumerate(dcx):
        for k, dy in enumerate(dcy):
            af1 = circle_array.get_array_factor_dcos(dx, dy,
                                                     np.deg2rad(target_theta),
                                                     np.deg2rad(target_azm))
            af2 = spiral_array.get_array_factor_dcos(dx, dy,
                                                     np.deg2rad(target_theta),
                                                     np.deg2rad(target_azm))
            afs_circle[i, k] = np.abs(af1)
            afs_spiral[i, k] = np.abs(af2)

    afs_circle_pow = 20*np.log10(afs_circle)
    afs_spiral_pow = 20*np.log10(afs_spiral)

    # ----------------------------------------------------------------------------
    # Plotting
    # ----------------------------------------------------------------------------

    # geometry plot
    plt.figure()
    plt.tight_layout()
    plt.scatter(
        circle_array.pos.real / lam, circle_array.pos.imag / lam, marker="X", s=100
    )

    plt.grid(1)

    # plot array geometry line
    cont = circle_array.get_contour(500)
    plt.plot(cont.real/lam, cont.imag/lam, linestyle="dashed", color="lightgray",
             zorder=0)

    plt.xlim([-2, 2])
    plt.ylim([-2, 2])
    plt.xlabel("x / $\\lambda$")
    plt.ylabel("y / $\\lambda$")
    plt.title("Circular Array Geometry")

    plt.axis('equal')
    my_savefig("t7-geo-circ.pdf")

    plt.figure()
    plt.scatter(pos_data_circle[:, 0], pos_data_circle[:, 1])
    plt.xlim([-1, 1])
    plt.ylim([-1, 1])
    plt.grid(1)
    plt.xlabel("$dcosx=\\sin(\\theta)\\cos(\\phi)$")
    plt.ylabel("$dcosy=\\sin(\\theta)\\sin(\\phi)$")
    plt.title("Circular Array AOA coverage")
    my_savefig("t7-aoa-circ.pdf")

    plt.figure()
    plt.tight_layout()
    plt.scatter(
        spiral_array.pos.real / lam, spiral_array.pos.imag / lam, marker="X", s=100
    )

    plt.grid(1)

    # plot array geometry line
    cont = spiral_array.get_contour(500)
    plt.plot(cont.real/lam, cont.imag/lam, linestyle="dashed", color="lightgray",
             zorder=0)

    plt.xlim([-2, 2])
    plt.ylim([-2, 2])
    plt.xlabel("x / $\\lambda$")
    plt.ylabel("y / $\\lambda$")
    plt.title("Spiral Array Geometry")

    plt.axis('equal')
    my_savefig("t7-geo-spir.pdf")

    plt.figure()
    plt.scatter(pos_data_spiral[:, 0], pos_data_spiral[:, 1])
    plt.xlim([-1, 1])
    plt.ylim([-1, 1])
    plt.grid(1)
    plt.xlabel("$dcosx=\\sin(\\theta)\\cos(\\phi)$")
    plt.ylabel("$dcosy=\\sin(\\theta)\\sin(\\phi)$")
    plt.title("Spiral Array AOA coverage")
    my_savefig("t7-aoa-spir.pdf")

    # plot rad patterns

    plt.figure()
    plt.title("Circle Array Factor")
    plt.axis('equal')
    plt.pcolor(dcx, dcy, afs_circle_pow, cmap='jet', rasterized=True)
    cbar = plt.colorbar()
    cbar.ax.set_ylabel("$20\\log_{10}{(AF)}$")
    plt.clim(np.max(afs_circle_pow)-20, np.max(afs_circle_pow))
    plt.xlabel("$\\sin{\\theta}\\cos{\\phi}$")
    plt.ylabel("$\\sin{\\theta}\\sin{\\phi}$")
    my_savefig("t7-rad-circ.pdf")

    plt.figure()
    plt.title("Spiral Array Factor")
    plt.axis('equal')
    plt.pcolor(dcx, dcy, afs_spiral_pow, cmap='jet', rasterized=True)
    cbar = plt.colorbar()
    cbar.ax.set_ylabel("$20\\log_{10}{(AF)}$")
    plt.clim(np.max(afs_spiral_pow)-20, np.max(afs_spiral_pow))
    plt.xlabel("$\\sin{\\theta}\\cos{\\phi}$")
    plt.ylabel("$\\sin{\\theta}\\sin{\\phi}$")
    my_savefig("t7-rad-spir.pdf")

    # Create a sphere
    # unused
    r = 1
    pi = np.pi
    cos = np.cos
    sin = np.sin
    phi1, theta1 = np.mgrid[0.0:pi:100j, 0.0:2.0*pi:100j]
    x = r*sin(phi1)*cos(theta1)
    y = r*sin(phi1)*sin(theta1)
    z = r*cos(phi1)

    dcx = pos_data_circle[:, 0]
    dcy = pos_data_circle[:, 1]

    phi = np.arctan(dcx/dcy)
    theta = np.arcsin(dcy * np.sqrt((dcx**2 + dcy**2)/(dcy**2)))

    # phi = phi_circ[:, 0]
    # theta = theta_circ[:, 0]

    r = 1.0
    xx = r * np.sin(theta)*np.sin(phi)
    yy = r * np.sin(theta)*np.cos(phi)
    zz = r * np.cos(theta)

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    ax.plot_surface(
        x, y, z,  rstride=1, cstride=1, color='c', alpha=0.3, linewidth=0)

    ax.scatter(xx, yy, zz, color="k", s=20)
    ax.set_aspect("equal")

    plt.show()


if __name__ == "__main__":
    main()
