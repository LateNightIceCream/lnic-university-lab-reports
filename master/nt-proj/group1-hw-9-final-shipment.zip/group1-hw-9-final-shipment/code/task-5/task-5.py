import scipy.io as spio
import matplotlib.pyplot as plt
import numpy as np

# plt.style.use('ggplot')
# plt.rcParams['text.usetex'] = True
# plt.rcParams['figure.figsize'] = 16, 10
# plt.rcParams['font.size'] = 12
# plt.rcParams['figure.titlesize'] = 13


def load_data(file):
    mat = spio.loadmat(file, squeeze_me=True)
    datenums = mat["datenums"]
    ranges = mat["ranges"]
    data = mat["data"]
    t = (datenums - np.floor(np.min(datenums))) * 24
    return (t, ranges, data)


def coherent_integration(time, data, ci):
    """
    a "problem" with this is that np.array_split will
    try to split the data into evenly sized chunks
    and if it is not possible it will distribute the remainder
    across the first values. So e.g. if ci=8 but the data length is
    17068, there will be a total of 2133 chunks, where 2129 chunks are size 8
    and 4 chunks are size 9.
    this will then also result in a different time difference for the first 4
    samples compared to the rest (since 9 values are averaged instead of 8),
    which might affect the fft
    """
    # how many splits
    n_data_split = int(np.floor(data.shape[1] / ci))

    split_data = np.array_split(data, n_data_split, axis=1)
    split_time = np.array_split(time, n_data_split)

    newlist = []
    timelist = []
    for i, m in enumerate(split_data):
        dat_mean = np.mean(m, axis=1)
        newlist.append(dat_mean)
        timelist.append(np.mean(split_time[i]))

    new_data = np.stack(newlist, axis=1)
    new_time = np.stack(timelist)

    return (new_time, new_data)


def get_spectra(data, ts):
    """
    assumes time series data is distributed along axis=1
    """
    N = data.shape[1]
    spectra = np.fft.fft(data, axis=1) / N
    freq = np.fft.fftfreq(N, ts)
    freq = np.fft.fftshift(freq)
    spectra = np.fft.fftshift(spectra, axes=1)
    return (freq, spectra)


def make_ci(t, y, ci):
    nptsn = int(np.floor(len(y) / ci))
    yn = np.empty(nptsn) + 1j * np.empty(nptsn)
    tn = np.empty(nptsn)
    for i in range(0, nptsn):
        yn[i] = np.mean(y[i * ci:i * ci + ci - 1])
        tn[i] = np.mean(t[i * ci:(i + 1) * ci])
    return tn, yn


def rx_cross_spectra(data, ts, rx1_idx, rx2_idx):
    f, spectra = get_spectra(data, ts)
    spec_rx1 = spectra[:, :, rx1_idx]
    spec_rx2 = spectra[:, :, rx2_idx]
    xspec = np.multiply(spec_rx1, np.conj(spec_rx2))
    return f, xspec


def remove_dc(data):
    noDP = np.size(data, 1)
    dc = np.repeat(np.mean(data, axis=1)[:, :, np.newaxis], noDP, axis=2)
    dc = np.swapaxes(dc, 1, 2)
    return data - dc


def place_cplot_axs(data, fig, ax, title, xlab="", ylab="", clab="", **kwargs):
    # rasterized=True is necessary to not have a huge output file size
    # and to avoid the white grid lines on the color mesh
    msh = ax.pcolor(data[0], data[1], data[2],
                    cmap="jet", rasterized=True, **kwargs)
    ax.set_title(title)
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_xlim(-5, 5)
    ax.grid(False)
    fig.colorbar(msh, ax=ax, label=clab)


def my_savefig(name):
    plt.savefig("output/" + name)


def main():
    file = "../data/20230620_MAARSY_1_Gr1_RAW"
    t, ranges, data = load_data(file)

    data_no_dc = remove_dc(data)

    t_ci, data_ci = coherent_integration(t, data_no_dc, 17)

    tsec = t_ci * 60 * 60
    ts = tsec[42] - tsec[41]

    print("data duration seconds:")
    print(np.max(tsec)-np.min(tsec))

    f, specs = get_spectra(data_ci, ts)

    f_x, x_spec_2_3 = rx_cross_spectra(data_ci, ts, 1, 2)
    f_x, x_spec_2_4 = rx_cross_spectra(data_ci, ts, 1, 3)
    f_x, x_spec_3_4 = rx_cross_spectra(data_ci, ts, 2, 3)

    # power plot vs range
    plt.figure(constrained_layout=True)
    powers = 20*np.log10(np.mean(abs(data_ci), 1))
    plt.plot(powers[..., 0], ranges, label="Rx1")
    plt.plot(powers[..., 1], ranges, label="Rx2")
    plt.plot(powers[..., 2], ranges, label="Rx3")
    plt.plot(powers[..., 3], ranges, label="Rx4")
    plt.xlabel("power / dB$V^2$")
    plt.ylabel("range / km")
    plt.legend()
    plt.grid()

    my_savefig("t5-power.pdf")

    # fft mag / phase plots
    fig, axs = plt.subplots(2, 2, constrained_layout=True)

    mags = np.abs(specs)
    angs = np.rad2deg(np.angle(specs))

    # Rx1 magnitudes
    place_cplot_axs((f_x, ranges, mags[..., 0]), fig, axs[0][0],
                    "Rx1 Spectral Magnitudes",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="|FFT(Rx1)|",
                    clim=(0, 250))

    # Rx1 phases
    place_cplot_axs((f_x, ranges, angs[..., 0]), fig, axs[1][0],
                    "Rx1 Spectral Magnitudes",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="arg(FFT(Rx1)) / °",
                    clim=(-180, 180))

    # Rx2 magnitudes
    place_cplot_axs((f_x, ranges, mags[..., 1]), fig, axs[0][1],
                    "Rx2 Spectral Phases",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="|FFT(Rx2)|",
                    clim=(0, 250))

    # Rx2 phases
    place_cplot_axs((f_x, ranges, angs[..., 1]), fig, axs[1][1],
                    "Rx2 Spectral Phases",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="arg(FFT(Rx2)) / °",
                    clim=(-180, 180))

    my_savefig("t5-reg-mag-phase.pdf")

    # cross spectra magnitudes
    fig, axs = plt.subplots(2, 3, constrained_layout=True, figsize=(10, 6))
    fig.suptitle("Cross-Spectra")

    place_cplot_axs((f_x, ranges, np.abs(x_spec_2_3)), fig, axs[0][0],
                    "Rx2-Rx3, magnitudes",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="|$\\Gamma_{2,3}$|",
                    clim=(0, 250))

    place_cplot_axs((f_x, ranges, np.abs(x_spec_2_4)), fig, axs[0][1],
                    "Rx2-Rx4, magnitudes",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="|$\\Gamma_{2,4}$|",
                    clim=(0, 250))

    place_cplot_axs((f_x, ranges, np.abs(x_spec_3_4)), fig, axs[0][2],
                    "Rx3-Rx4, magnitudes",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="|$\\Gamma_{3,4}$|",
                    clim=(0, 250))

    # cross spectra phases
    place_cplot_axs((f_x, ranges, np.rad2deg(np.angle(x_spec_2_3))),
                    fig, axs[1][0],
                    "Rx2-Rx3, phases",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="arg($\\Gamma_{2,3}$) / °",
                    clim=(-180, 180))

    place_cplot_axs((f_x, ranges, np.rad2deg(np.angle(x_spec_2_4))),
                    fig, axs[1][1],
                    "Rx2-Rx4, phases",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="arg($\\Gamma_{2,4}$) / °",
                    clim=(-180, 180))

    place_cplot_axs((f_x, ranges, np.rad2deg(np.angle(x_spec_3_4))),
                    fig, axs[1][2],
                    "Rx3-Rx4, phases",
                    xlab="frequency / Hz",
                    ylab="range / km",
                    clab="arg($\\Gamma_{3,4}$) / °",
                    clim=(-180, 180))

    my_savefig("t5-xspec-mag-phase.pdf")

    plt.show()


if __name__ == "__main__":
    main()
